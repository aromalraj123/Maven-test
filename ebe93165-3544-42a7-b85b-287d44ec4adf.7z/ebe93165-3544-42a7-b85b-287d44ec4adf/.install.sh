#!/bin/sh
sudo apt update;
sudo apt install maven -y;
mvn clean;